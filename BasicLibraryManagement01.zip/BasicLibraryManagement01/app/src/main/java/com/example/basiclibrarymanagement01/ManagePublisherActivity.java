package com.example.basiclibrarymanagement01;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ManagePublisherActivity extends AppCompatActivity {

    private DataRepository dataRepository;
    private EditText editTextPublisherName, editTextPublisherAddress, editTextPublisherPhone;
    private ListView listViewPublishers;
    private ArrayAdapter<Publisher> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_publisher);

        dataRepository = new DataRepository(this);

        editTextPublisherName = findViewById(R.id.editTextPublisherName);
        editTextPublisherAddress = findViewById(R.id.editTextPublisherAddress);
        editTextPublisherPhone = findViewById(R.id.editTextPublisherPhone);


        Button btnAddPublisher = findViewById(R.id.btnAddPublisher);
        Button btnUpdatePublisher = findViewById(R.id.btnUpdatePublisher);
        Button btnDeletePublisher = findViewById(R.id.btnDeletePublisher);
        Button btnViewPublishers = findViewById(R.id.btnViewPublishers);

        btnAddPublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add a publisher
                String name = editTextPublisherName.getText().toString().trim();
                String address = editTextPublisherAddress.getText().toString().trim();
                String phone = editTextPublisherPhone.getText().toString().trim();

                if (!name.isEmpty() && !address.isEmpty() && !phone.isEmpty()) {
                    Publisher publisher = new Publisher(name, address, phone);
                    long result = dataRepository.addPublisher(publisher);
                    if (result != -1) {
                        Toast.makeText(ManagePublisherActivity.this, "Publisher added successfully", Toast.LENGTH_SHORT).show();
                        refreshPublisherList();
                    } else {
                        Toast.makeText(ManagePublisherActivity.this, "Failed to add publisher", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManagePublisherActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnViewPublishers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewPublishers = findViewById(R.id.listViewPublishers);
                refreshPublisherList();
            }
        });

        btnUpdatePublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update a publisher
                String name = editTextPublisherName.getText().toString().trim();
                String address = editTextPublisherAddress.getText().toString().trim();
                String phone = editTextPublisherPhone.getText().toString().trim();

                if (!name.isEmpty() && !address.isEmpty() && !phone.isEmpty()) {
                    Publisher publisher = new Publisher(name, address, phone);
                    int rowsAffected = dataRepository.updatePublisher(publisher);
                    if (rowsAffected > 0) {
                        Toast.makeText(ManagePublisherActivity.this, "Publisher updated successfully", Toast.LENGTH_SHORT).show();
                        refreshPublisherList();
                    } else {
                        Toast.makeText(ManagePublisherActivity.this, "Failed to update publisher", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManagePublisherActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeletePublisher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete a publisher
                String name = editTextPublisherName.getText().toString().trim();
                if (!name.isEmpty()) {
                    int rowsDeleted = dataRepository.deletePublisher(name);
                    if (rowsDeleted > 0) {
                        Toast.makeText(ManagePublisherActivity.this, "Publisher deleted successfully", Toast.LENGTH_SHORT).show();
                        refreshPublisherList();
                    } else {
                        Toast.makeText(ManagePublisherActivity.this, "Failed to delete publisher", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManagePublisherActivity.this, "Please enter publisher name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void refreshPublisherList() {
        List<Publisher> publishers = dataRepository.getAllPublishers();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, publishers);
        listViewPublishers.setAdapter(adapter);
    }
}
