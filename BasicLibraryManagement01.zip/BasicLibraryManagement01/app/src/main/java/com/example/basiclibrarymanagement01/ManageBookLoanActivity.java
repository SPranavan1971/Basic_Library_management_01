package com.example.basiclibrarymanagement01;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class ManageBookLoanActivity extends AppCompatActivity {

    private DataRepository dataRepository;

    private EditText editTextAccessNo, editTextBranchId, editTextCardNo, editTextDateOut, editTextDateDue, editTextDateReturned;
    private ListView listViewBookLoans;
    private ArrayAdapter<BookLoan> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book_loan);

        dataRepository = new DataRepository(this);

        editTextAccessNo = findViewById(R.id.editTextAccessNo);
        editTextBranchId = findViewById(R.id.editTextBranchId);
        editTextCardNo = findViewById(R.id.editTextCardNo);
        editTextDateOut = findViewById(R.id.editTextDateOut);
        editTextDateDue = findViewById(R.id.editTextDateDue);
        editTextDateReturned = findViewById(R.id.editTextDateReturned);

        Button btnAddBookLoan = findViewById(R.id.btnAddBookLoan);
        Button btnGetAllBookLoans = findViewById(R.id.btnGetAllBookLoans);
        Button btnUpdateBookLoan = findViewById(R.id.btnUpdateBookLoan);
        Button btnDeleteBookLoan = findViewById(R.id.btnDeleteBookLoan);

        btnAddBookLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add a book loan
                String accessNo = editTextAccessNo.getText().toString().trim();
                String branchId = editTextBranchId.getText().toString().trim();
                String cardNo = editTextCardNo.getText().toString().trim();
                String dateOut = editTextDateOut.getText().toString().trim();
                String dateDue = editTextDateDue.getText().toString().trim();
                String dateReturned = editTextDateReturned.getText().toString().trim();

                if (!accessNo.isEmpty() && !branchId.isEmpty() && !cardNo.isEmpty() && !dateOut.isEmpty() && !dateDue.isEmpty() && !dateReturned.isEmpty()) {
                    BookLoan bookLoan = new BookLoan(accessNo, branchId, cardNo, dateOut, dateDue, dateReturned);
                    long result = dataRepository.addBookLoan(bookLoan);
                    if (result != -1) {
                        Toast.makeText(ManageBookLoanActivity.this, "Book loan added successfully", Toast.LENGTH_SHORT).show();
                        refreshBookLoanList();
                    } else {
                        Toast.makeText(ManageBookLoanActivity.this, "Failed to add book loan", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookLoanActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGetAllBookLoans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewBookLoans = findViewById(R.id.listViewBookLoans);
                refreshBookLoanList();
            }
        });

        btnUpdateBookLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update a book loan
                String accessNo = editTextAccessNo.getText().toString().trim();
                String branchId = editTextBranchId.getText().toString().trim();
                String cardNo = editTextCardNo.getText().toString().trim();
                String dateOut = editTextDateOut.getText().toString().trim();
                String dateDue = editTextDateDue.getText().toString().trim();
                String dateReturned = editTextDateReturned.getText().toString().trim();

                if (!accessNo.isEmpty() && !branchId.isEmpty() && !cardNo.isEmpty() && !dateOut.isEmpty() && !dateDue.isEmpty() && !dateReturned.isEmpty()) {
                    BookLoan bookLoan = new BookLoan(accessNo, branchId, cardNo, dateOut, dateDue, dateReturned);
                    int result = dataRepository.updateBookLoan(bookLoan);
                    if (result > 0) {
                        Toast.makeText(ManageBookLoanActivity.this, "Book loan updated successfully", Toast.LENGTH_SHORT).show();
                        refreshBookLoanList();
                    } else {
                        Toast.makeText(ManageBookLoanActivity.this, "Failed to update book loan", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookLoanActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeleteBookLoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete a book loan
                String accessNoToDelete = editTextAccessNo.getText().toString().trim();
                if (!accessNoToDelete.isEmpty()) {
                    int result = dataRepository.deleteBookLoan(accessNoToDelete);
                    if (result > 0) {
                        Toast.makeText(ManageBookLoanActivity.this, "Book loan deleted successfully", Toast.LENGTH_SHORT).show();
                        refreshBookLoanList();
                    } else {
                        Toast.makeText(ManageBookLoanActivity.this, "Failed to delete book loan", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookLoanActivity.this, "Please enter access number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void refreshBookLoanList() {
        List<BookLoan> bookLoans = dataRepository.getAllBookLoans();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookLoans);
        listViewBookLoans.setAdapter(adapter);
    }
}
