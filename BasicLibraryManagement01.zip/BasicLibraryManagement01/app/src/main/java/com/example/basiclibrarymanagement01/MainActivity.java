package com.example.basiclibrarymanagement01;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set click listeners for buttons
        findViewById(R.id.btnBook).setOnClickListener(this);
        findViewById(R.id.btnPublisher).setOnClickListener(this);
        findViewById(R.id.btnBranch).setOnClickListener(this);
        findViewById(R.id.btnMember).setOnClickListener(this);
        findViewById(R.id.btnBookAuthor).setOnClickListener(this);
        findViewById(R.id.btnBookCopy).setOnClickListener(this);
        findViewById(R.id.btnBookLoan).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // Handle button clicks
        if (v.getId() == R.id.btnBook) {
            startActivity(new Intent(this, ManageBookActivity.class));
        } else if (v.getId() == R.id.btnPublisher) {
            startActivity(new Intent(this, ManagePublisherActivity.class));
        } else if (v.getId() == R.id.btnBranch) {
            startActivity(new Intent(this, ManageBranchActivity.class));
        } else if (v.getId() == R.id.btnMember) {
            startActivity(new Intent(this, ManageMemberActivity.class));
        } else if (v.getId() == R.id.btnBookAuthor) {
            startActivity(new Intent(this, ManageBookAuthorActivity.class));
        } else if (v.getId() == R.id.btnBookCopy) {
            startActivity(new Intent(this, ManageBookCopyActivity.class));
        } else if (v.getId() == R.id.btnBookLoan) {
            startActivity(new Intent(this, ManageBookLoanActivity.class));
        }
    }
}

