package com.example.basiclibrarymanagement01;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ManageBookActivity extends AppCompatActivity {

    private DataRepository dataRepository;
    private EditText editTextBookId, editTextTitle, editTextPublisherName;
    private ListView listViewBooks;
    private ArrayAdapter<Book> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book);

        dataRepository = new DataRepository(this);

        editTextBookId = findViewById(R.id.editTextBookId);
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextPublisherName = findViewById(R.id.editTextPublisherName);

        Button btnAddBook = findViewById(R.id.btnAddBook);
        Button btnGetAllBooks = findViewById(R.id.btnGetAllBooks);
        Button btnUpdateBook = findViewById(R.id.btnUpdateBook);
        Button btnDeleteBook = findViewById(R.id.btnDeleteBook);


        btnAddBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add a book
                String bookId = editTextBookId.getText().toString().trim();
                String title = editTextTitle.getText().toString().trim();
                String publisherName = editTextPublisherName.getText().toString().trim();

                if (!bookId.isEmpty() && !title.isEmpty() && !publisherName.isEmpty()) {
                    Book book = new Book(bookId, title, publisherName);
                    long result = dataRepository.addBook(book);
                    if (result != -1) {
                        Toast.makeText(ManageBookActivity.this, "Book added successfully", Toast.LENGTH_SHORT).show();
                        refreshBookList();
                    } else {
                        Toast.makeText(ManageBookActivity.this, "Failed to add book", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGetAllBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewBooks = findViewById(R.id.listViewBooks);
                refreshBookList();

            }
        });

        btnUpdateBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update a book
                String bookId = editTextBookId.getText().toString().trim();
                String title = editTextTitle.getText().toString().trim();
                String publisherName = editTextPublisherName.getText().toString().trim();

                if (!bookId.isEmpty() && !title.isEmpty() && !publisherName.isEmpty()) {
                    Book book = new Book(bookId, title, publisherName);
                    int result = dataRepository.updateBook(book);
                    if (result > 0) {
                        Toast.makeText(ManageBookActivity.this, "Book updated successfully", Toast.LENGTH_SHORT).show();
                        refreshBookList();
                    } else {
                        Toast.makeText(ManageBookActivity.this, "Failed to update book", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeleteBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete a book
                String bookId = editTextBookId.getText().toString().trim();
                if (!bookId.isEmpty()) {
                    int result = dataRepository.deleteBook(bookId);
                    if (result > 0) {
                        Toast.makeText(ManageBookActivity.this, "Book deleted successfully", Toast.LENGTH_SHORT).show();
                        editTextBookId.setText("");
                        editTextTitle.setText("");
                        editTextPublisherName.setText("");
                        refreshBookList();
                    } else {
                        Toast.makeText(ManageBookActivity.this, "Failed to delete book", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookActivity.this, "Please enter book ID", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    private void refreshBookList() {
        List<Book> books = dataRepository.getAllBooks();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, books);
        listViewBooks.setAdapter(adapter);
    }
}
