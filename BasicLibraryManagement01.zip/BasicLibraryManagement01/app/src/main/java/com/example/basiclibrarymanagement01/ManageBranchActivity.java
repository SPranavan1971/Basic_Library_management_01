package com.example.basiclibrarymanagement01;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ManageBranchActivity extends AppCompatActivity {

    private DataRepository dataRepository;
    private EditText editTextBranchId, editTextName, editTextAddress;
    private ListView listViewBranches;
    private ArrayAdapter<Branch> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_branch);

        dataRepository = new DataRepository(this);

        editTextBranchId = findViewById(R.id.editTextBranchId);
        editTextName = findViewById(R.id.editTextBranchName);
        editTextAddress = findViewById(R.id.editTextBranchAddress);


        Button btnAddBranch = findViewById(R.id.btnAddBranch);
        Button btnGetAllBranches = findViewById(R.id.btnGetAllBranches);
        Button btnUpdateBranch = findViewById(R.id.btnUpdateBranch);
        Button btnDeleteBranch = findViewById(R.id.btnDeleteBranch);

        btnAddBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add a branch
                String branchId = editTextBranchId.getText().toString().trim();
                String name = editTextName.getText().toString().trim();
                String address = editTextAddress.getText().toString().trim();

                if (!branchId.isEmpty() && !name.isEmpty() && !address.isEmpty()) {
                    Branch branch = new Branch(branchId, name, address);
                    long addBranchResult = dataRepository.addBranch(branch);
                    if (addBranchResult != -1) {
                        Toast.makeText(ManageBranchActivity.this, "Branch added successfully", Toast.LENGTH_SHORT).show();
                        refreshBranchList();
                    } else {
                        Toast.makeText(ManageBranchActivity.this, "Failed to add branch", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBranchActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGetAllBranches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewBranches = findViewById(R.id.listViewBranches);
                refreshBranchList();
            }
        });

        btnUpdateBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update a branch
                String branchId = editTextBranchId.getText().toString().trim();
                String name = editTextName.getText().toString().trim();
                String address = editTextAddress.getText().toString().trim();

                if (!branchId.isEmpty() && !name.isEmpty() && !address.isEmpty()) {
                    Branch branch = new Branch(branchId, name, address);
                    int updateResult = dataRepository.updateBranch(branch);
                    if (updateResult > 0) {
                        Toast.makeText(ManageBranchActivity.this, "Branch updated successfully", Toast.LENGTH_SHORT).show();
                        refreshBranchList();
                    } else {
                        Toast.makeText(ManageBranchActivity.this, "Failed to update branch", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBranchActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeleteBranch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete a branch
                String branchIdToDelete = editTextBranchId.getText().toString().trim();
                if (!branchIdToDelete.isEmpty()) {
                    int deleteResult = dataRepository.deleteBranch(branchIdToDelete);
                    if (deleteResult > 0) {
                        Toast.makeText(ManageBranchActivity.this, "Branch deleted successfully", Toast.LENGTH_SHORT).show();
                        refreshBranchList();
                    } else {
                        Toast.makeText(ManageBranchActivity.this, "Failed to delete branch", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBranchActivity.this, "Please enter branch ID", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void refreshBranchList() {
        List<Branch> branches = dataRepository.getAllBranches();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, branches);
        listViewBranches.setAdapter(adapter);
    }
}
