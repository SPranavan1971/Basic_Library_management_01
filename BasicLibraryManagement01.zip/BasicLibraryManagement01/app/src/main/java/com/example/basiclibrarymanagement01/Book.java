package com.example.basiclibrarymanagement01;

public class Book {
    private String id;
    private String title;
    private String publisherName;

    public Book(String id, String title, String publisherName) {
        this.id = id;
        this.title = title;
        this.publisherName = publisherName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublisherName() {
        return publisherName;
    }

    public void setPublisherName(String publisherName) {
        this.publisherName = publisherName;
    }

    @Override
    public String toString() {
        return "Book ID: " + id + "\n" +
                "Title : " + title + "\n" +
                "Publisher Name: " + publisherName;
    }
}
